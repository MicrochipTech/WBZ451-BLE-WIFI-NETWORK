/*******************************************************************************
 This project is a bridge or gateway device for a MiWi Star network.
 The hardware used: 
        (1) Curiosity Nano Base Board
        (1) ATSAMD21 Curiosity Nano Board
        (2) RNBD451 Add-On Boards
 The RNBD451 Add-On boards are re-programmed with the PAN Coordinator firmware
 The ATSAMD21 Curiosity Nano is programmed with this firmware
 Network traffic is passed to a Dashboard written in Python running on a PC
 This version supports Dashboard control of the end node LED's.
 
 Keith Donadio          7/29/2024
 *******************************************************************************/

// *****************************************************************************
// Section: Included Files
// *****************************************************************************
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include <string.h>
#include <stdio.h>

//-------------------------------------------------------------------
// MikroBus Socket #1 (SERCOM 0)
// PAN Coordinator A variables / buffer
char msgPanA[] = " * * * *  PAN Coordinator A: Ready * * * *\r\n";
char panA_buffer[100];
unsigned char panA_Index = 0;
bool panA_DataReady = 0;
char rxPanA;

//-------------------------------------------------------------------
// MikroBus Socket #2 (SERCOM 3)
// PAN Coordinator B variables / buffer
char msgPanB[] = " * * * *  PAN Coordinator B: Ready * * * *\r\n";
char panB_buffer[100];
unsigned char panB_Index = 0;
bool panB_DataReady = 0;
char rxPanB;

//-------------------------------------------------------------------
// USB/UART on SAMD21 Nano (SERCOM 5 Transmit Data)
char dash_buffer[100];          // Buffer to write to the dashboard
unsigned char dash_Index = 0;
bool dash_DataReady = 0;
char rxDash;

// USB/UART on SAMD21 Nano (SERCOM 5 Receive Data)
char dashRX_buffer[100];          // Buffer to read from the dashboard
unsigned char dashRX_Index = 0;
bool dashRX_DataReady = 0;
char dashRX;
//uint8_t cbNum = 0;

#define BUFFER_SIZE     50      // Number of elements in main bridge buffer
#define STRING_LENGTH   100      // Length of the string from each PAN Coordinator

typedef struct{
    char buffer[BUFFER_SIZE][STRING_LENGTH + 1];
    uint8_t head;
    uint8_t tail;
    uint8_t count;
}CircularBuffer;

CircularBuffer cb;
  
uint8_t tick = 0;

//-------------------------------------------------------------------
// Function Prototypes
void initCircularBuffer(CircularBuffer *cb);
uint8_t writeQueue(CircularBuffer *cb, char *data, uint8_t num);
int8_t readQueue(CircularBuffer *cb, char *data);

void SERCOM5_PutChar(char t);
void SERCOM5_Puts(const char *s);

//-------------------------------------------------------------------
// 100mS timer
void TC3_Ticker(TC_TIMER_STATUS status, uintptr_t context)
{
    // Every 200mS parse the circular buffer and send the PAN Coordinator data 
    // to the dashboard running on the laptop via SERCOM5
    if(tick == 2)
        {
        dash_DataReady = 1;
        }
    //
    if(tick == 5)    // 500mS
        {
        tick = 0;
        LED_Toggle();
        }
    //
    tick++;
    
}

//-------------------------------------------------------------------
// PAN Coordinator A USART receive callback (ISR)
// Receives the packet from the Coordinator and saves into a buffer
// <CR><LF> are used to receive the packet only
void PAN_A_ReadCallback(uintptr_t context)
{
    if((rxPanA == '\n' )|| (rxPanA == '\r'))// Check for end of packet 
        {
        panA_DataReady = 1;                 // New packet was received
        }
    else    
        {
        panA_buffer[panA_Index++] = rxPanA; // Load data in buffer
        }
    //
    SERCOM0_USART_Read(&rxPanA, 1);         // Trigger a new read event
}

//-------------------------------------------------------------------
// PAN Coordinator B USART receive callback (ISR)
// Receives the packet from the Coordinator and saves into a buffer
// <CR><LF> are used to receive the packet only
void PAN_B_ReadCallback(uintptr_t context)
{
    if((rxPanB == '\n') || (rxPanB == '\r'))// Check for end of packet
        {
        panB_DataReady = 1;                 // New packet was received
        }
    else    
        {
        panB_buffer[panB_Index++] = rxPanB; // Load data in buffer
        }
    //
    SERCOM3_USART_Read(&rxPanB, 1);         // Trigger a new read event
}

//-------------------------------------------------------------------
// ATSAMD21 USART receive callback (ISR)
// Receives the packet from the Python Dashboard 
// <CR><LF> are used to receive the packet only
//void DASH_ReadCallback(uintptr_t context)
//{
//    if((dashRX == '\n') || (dashRX == '\r'))// Check for end of packet
//        {
//        dashRX_DataReady = 1;                 // New packet was received
//        }
//    else    
//        {
//        dashRX_buffer[dashRX_Index++] = dashRX; // Load data in buffer
//        }
//    //
//    SERCOM5_USART_Read(&dashRX, 1);         // Trigger a new read event
//}

// *****************************************************************************
// *  *  *  *  M A I N      F U N C T I O N  *  *  *  *
// *****************************************************************************
int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
  
    // Setup circular buffer
    initCircularBuffer(&cb);
    
    // Timer 3 callback 
    TC3_TimerCallbackRegister(TC3_Ticker, 0);
    TC3_TimerStart();
    
    // USART 0 callback (Socket 1)
    SERCOM0_USART_ReadCallbackRegister(PAN_A_ReadCallback, 0);
    SERCOM0_USART_Read(&rxPanA, 1);
    SERCOM5_USART_Write(&msgPanA[0], 44);
    
    // USART 3 callback (Socket 2)     
    SERCOM3_USART_ReadCallbackRegister(PAN_B_ReadCallback, 0);
    SERCOM3_USART_Read(&rxPanB, 1);
    SERCOM5_USART_Write(&msgPanB[0], 44);
    
    // USART 5 callback - Dashboard     
//    SERCOM5_USART_ReadCallbackRegister(DASH_ReadCallback, 0);
//    SERCOM5_USART_Read(&rxDash, 1);
    
    while ( true )
    {
        //----------------------------------------------------------------------
        // Received a byte over the UART (SERCOM5). 
        if ((SERCOM5_REGS->USART_INT.SERCOM_INTFLAG & SERCOM_USART_INT_INTFLAG_RXC_Msk) == SERCOM_USART_INT_INTFLAG_RXC_Msk)
            {
            dashRX = SERCOM5_USART_ReadByte();          // Get the byte
            //
            if((dashRX == '\n') || (dashRX == '\r'))    // Check for end of packet
                {
                dashRX_DataReady = 1;                   // New packet was received
                }
            else    
                {
                dashRX_buffer[dashRX_Index++] = dashRX; // Load data in buffer
                }
            }
        
        //---------------------------------------------------------------------- 
        // Received a command from the Dashboard - message to turn on/off an LED on an end node
        if(dashRX_DataReady == 1)
            {
//            printf("We received: %s \r\n", dashRX_buffer);
            SERCOM5_USART_Write(dashRX_buffer, dashRX_Index);   // Let's see what was sent to us here . . . 
            //
            if(strstr(dashRX_buffer, "3030") > 0)
                {
                // Send message to PAN B
                SERCOM3_USART_Write(&dashRX_buffer, dashRX_Index);
                SERCOM3_USART_Write("\r\n", 2);                                
                SERCOM5_USART_Write("\nWrote data packet to PAN B \r\n", 29);  
                }
            //
            if(strstr(dashRX_buffer, "2017") > 0)
                {
                // Send message to PAN A
                SERCOM0_USART_Write(&dashRX_buffer, dashRX_Index);
                SERCOM0_USART_Write("\r\n", 2);                
                SERCOM5_USART_Write("\nWrote data packet to PAN A \r\n", 29);  
                }
            //
            dashRX_DataReady = 0;                               // Clear flag
            dashRX_Index = 0;                                   // Reset index counter
            memset(dashRX_buffer, 0, sizeof dashRX_buffer);     // Clear buffer                                
            //            
            }
       
        //----------------------------------------------------------------------        
        // Check for switch press
        if(SWITCH_Get() == SWITCH_STATE_PRESSED)
            {
//            SERCOM5_USART_Write("Switch was pressed \r\n", 21);  
            LED_On();
            while(SWITCH_Get() == SWITCH_STATE_PRESSED);
            }
        
        //----------------------------------------------------------------------        
        // If we received data from PAN A, send to the python Dashboard
        if(panA_DataReady)
            {
            writeQueue(&cb, panA_buffer, panA_Index);            // Save packet to circular buffer
//            SERCOM5_USART_Write(panA_buffer, panA_Index);      // Send out the USB connection            
//            SERCOM5_USART_Write("\r\n", 2);                    // add a CR+LF
//            printf("PAN A Index: %d \r\n", panA_Index);        // show the number of bytes 
            //
            panA_DataReady = 0;                                // Clear flag
            panA_Index = 0;                                    // Reset index counter
            memset(panA_buffer, 0, sizeof panA_buffer);        // Clear buffer        
            }

        //----------------------------------------------------------------------        
        // If we received data from PAN B, send to the python Dashboard
        if(panB_DataReady)
            {
            writeQueue(&cb, panB_buffer, panB_Index);            // Save packet to circular buffer
//            SERCOM5_USART_Write(panB_buffer, panB_Index);      // Send out the USB connection            
//            SERCOM5_USART_Write("\r\n", 2);                    // add a CR+LF
//            printf("PAN B Index: %d \r\n", panB_Index);        // show the number of bytes
            //            
            panB_DataReady = 0;                                // Clear flag
            panB_Index = 0;                                    // Reset index counter
            memset(panB_buffer, 0, sizeof panB_buffer);        // Clear buffer        
            }
        
        //----------------------------------------------------------------------        
        // The circular buffer has data so let's send it out now
        if(dash_DataReady)
            {
            if(cb.count > 0)
                {
                readQueue(&cb, dash_buffer); 
                printf(dash_buffer);
//                SERCOM5_USART_Write(dash_buffer, sizeof dash_buffer);
//                SERCOM5_USART_Write(&dash_buffer, 57);                
                }
            dash_DataReady = 0;                                     // Clear flag
            memset(dash_buffer, 0, sizeof dash_buffer);             // Clear buffer              
            }
        //
    }
    /* Execution should not come here during normal operation */
    return ( EXIT_FAILURE );
}

// Functions 
//------------------------------------------------------------------------------
// Initializes the circular buffer
void initCircularBuffer(CircularBuffer *cb)
{
    cb->head = 0;
    cb->tail = 0;
    cb->count = 0;
}

//------------------------------------------------------------------------------
// Write data into the circular buffer
uint8_t writeQueue(CircularBuffer *cb, char *data, uint8_t num) 
{
    if (cb->count < BUFFER_SIZE) 
        {
        strncpy(cb->buffer[cb->head], data, num);   // Copy packet into circular buffer        
        cb->head = (cb->head + 1) % BUFFER_SIZE;    // Keep track of cb index
        cb->count++;
        return 1;   // Success
        }
    //
    return 0;       // Buffer full
}

//------------------------------------------------------------------------------
// Read data from the circular buffer
int8_t readQueue(CircularBuffer *cb, char *data) 
{
    uint8_t num;
    //
    if (cb->count > 0) 
        {
        num = strlen(cb->buffer[cb->tail]);             // Number of bytes in circular buffer
        strncpy(data, cb->buffer[cb->tail], num);       // Copy circular buffer into dash buffer        
        data[57] = '\r';                                // Add <CR>
        data[58] = '\n';                                // Add <LF>
        memset(cb->buffer[cb->tail], 0, STRING_LENGTH); // Clear buffer                  
        cb->tail = (cb->tail + 1) % BUFFER_SIZE;
        cb->count--;
//        cbNum = num +2;                                 // Set the size to write on SERCOM5
        return 1;   // Success
        }
    return 0;       // Buffer empty
}

//------------------------------------------------------------------------------
// Write one character 
void SERCOM5_PutChar(char t)
{
    SERCOM5_REGS->USART_INT.SERCOM_DATA = t;
//    while(SERCOM5_REGS->USART_INT.SERCOM_STATUS == 1);
}

//------------------------------------------------------------------------------
// Write a string 
void SERCOM5_Puts(const char *s)
{
    while(*s)
        {
        SERCOM5_PutChar(*s++);
        }
}

//
// End of File
//